---
name: spc
version: 1.0
description: >
  SPC — Symbolic Prompt Compression. Interprète et exécute les instructions
  en DSL SPC générées par la Pierre de Rosette (rosetta.js / rosetta-editor.html).
  Déclencher dès que le message contient un ou plusieurs opérateurs SPC en
  majuscules (SCAN, ANALYZE, CREATE, ADD, FIND, DEBUG, DEPLOY, VALIDATE, CLONE,
  COMPARE, RESONE, TRANSDUIT, COMPRESS, APPLY, EXPAND, FILTER, ITERATE)
  ou les symboles ◈ § ⊜ ⟶ ▲ ⊘ ↻ ◊ ⌒.
  Ne pas déclencher sur du langage naturel pur — utiliser la Pierre de Rosette
  pour générer le DSL d'abord.
workflow: rosetta.js → DSL → Claude + SPC skill → output
---

# SPC — Interpréteur DSL

## Rôle

Recevoir des instructions compressées en DSL SPC, les interpréter, les exécuter.
L'utilisateur ne rédige pas le DSL manuellement — il est produit par la Pierre de
Rosette (outil local, zéro token). Ce skill est le moteur d'exécution côté Claude.

---

## Syntaxe DSL

```
OPÉRATEUR[param=valeur, ...]           instruction simple
OPÉRATEUR[param=valeur] → TYPE         avec format de sortie
A ⟶ B                                  pipe séquentiel (A puis B)
A | B                                  pipe alternatif (identique à ⟶)
A ? B : C                              conditionnel (si A → B, sinon C)
@skill::module                         pointeur de skill (lazy load)
OPÉRATEUR[◈]↻N                         forme courte de ITERATE
```

---

## Les 17 opérateurs

### Tier Cognitif
**SCAN**`[input, focus]`
Lecture rapide. Détecte les patterns sans décomposition profonde.
- `focus` : `surface` · `structure` · `anomalies` · `security` · `tests`
- Sortie par défaut : liste de tags

**ANALYZE**`[input, ctx, depth]`
Décomposition profonde selon un registre et une profondeur.
- `ctx` : `technique` · `symbolique` · `narratif` · `rationnel`
- `depth` : `1` (surface) · `2` (standard) · `3` (profond)

**COMPARE**`[a, b, dims]`
Contraste deux éléments sur des dimensions définies.
- `dims` : liste de dimensions de comparaison
- Sortie par défaut : table ou delta

**FIND**`[input, pattern, scope, type]`
Recherche dans la base de code.
- `scope` : `*` (tout) · `file` · `function`
- `type` : `usage` · `pattern` · `import` · `definition`

---

### Tier Transformatif
**RESONE**`[target, layers]`
Active les couches résonantes. Hérité du Métalangage des Résonances.
- `layers` : `sémantique` · `émotionnel` · `symbolique` · `narratif` · `all`

**TRANSDUIT**`[input, from, to]`
Change de registre ou de format.
- Registres : `rationnel` · `symbolique` · `narratif` · `code` · `prose` · `STÈLE` · `SPC`

**COMPRESS**`[input, format, ratio]`
Réduit à signature minimale.
- `format` : `STÈLE` · `SPC`
- `ratio` : `light` · `balanced` · `max`

---

### Tier Création
**CREATE**`[target, type, from]`
Génère depuis zéro.
- `type` : `component` · `function` · `api` · `schema` · `test` · `config`
- `from` : `scratch` · `template`

**ADD**`[target, what, scope]`
Injecte dans de l'existant.
- `what` : `feature` · `error-handling` · `logging` · `validation` · `pagination` · `auth` · `field`
- `scope` : `*` (tout) · `◈` (courant)

**CLONE**`[source, target, adapt, scope]`
Copie et adapte un pattern existant.
- `adapt` : `oui` · `non`
- `scope` : `composant` · `fonction` · `structure`

---

### Tier Flux
**APPLY**`[skill, input, mode]`
Invoque un skill ou une convention par pointeur.
- `skill` : `@nom::sous-module`

**EXPAND**`[seed, ctx, depth]`
Déploie une graine compressée vers un output étendu.
- `seed` : chaîne STÈLE · référence `§N` · `◈`

**FILTER**`[input, keep, drop]`
Sélectionne ou exclut selon des critères.

**ITERATE**`[op, n, var]`
Exécute un opérateur N fois avec variation d'un paramètre.
- Sortie : stack ordonné des résultats

---

### Tier Validation & Déploiement
**VALIDATE**`[input, scope]`
Vérifie la conformité.
- `scope` : `types` · `tests` · `security` · `schema` · `error`

**DEBUG**`[input, focus]`
Diagnostique et corrige.
- `focus` : `error` · `performance` · `logic`

**DEPLOY**`[input, env]`
Build et déploie.
- `env` : `prod` · `staging` · `dev`

---

## Symboles interface

| Symbole | Nom | Résolution |
|---------|-----|-----------|
| `◈` | FOCUS | Input courant — objet d'attention du message |
| `§N` | ANCRE | Référence nommée — `→ §1` stocke, `seed=§1` rappelle |
| `?` | BIFURQUE | Conditionnel — `A ? B : C` |
| `*` | TOUT | Wildcard — tous les éléments de l'ensemble |
| `▲` | MAX | Profondeur ou ratio maximum |
| `⊘` | NEG | Exclusion — équivaut à `drop=[...]` |
| `↻` | CYCLE | Forme courte d'ITERATE — `OP[◈]↻N` |
| `⟶` | PIPE | Séquence — passe l'output à l'opérateur suivant |
| `⊜` | SCELLER | Clôture et archive la session |
| `◊` | TRACE | État ou output de l'échange précédent |
| `⌒` | PLIER | Lazy load — charge le skill à l'usage seulement |

---

## Types de sortie

| Type | Format |
|------|--------|
| `prose` | Paragraphes en langue naturelle |
| `outline` | Liste hiérarchique structurée |
| `STÈLE` | Chaîne de glyphes + transcription mots-codes |
| `table` | Tableau markdown |
| `signature` | Chaîne courte ≤ 12 signes STÈLE |
| `code` | Bloc de code avec langage spécifié |

Si aucun type spécifié après `→` : prose courte.

---

## Protocole d'exécution

À chaque instruction SPC reçue :

1. **Identifier** l'opérateur, extraire les paramètres entre `[]`, noter le type après `→`
2. **Résoudre** les symboles (`◈`, `§N`, `▲`, `⊘`…) selon la table ci-dessus
3. **Décomposer** les pipes `⟶` et conditionnels `?` en étapes séquentielles
4. **Exécuter** chaque étape dans l'ordre
5. **Retourner** dans le format spécifié, ou prose courte si absent

**En cas d'ambiguïté :** poser une seule question de clarification, ne pas interpréter arbitrairement.

**En cas de pipe :** le résultat de l'étape N est l'input implicite de l'étape N+1.

**En cas de conditionnel :** évaluer A, prendre la branche B si résultat non vide, C sinon. Si `:` absent et résultat vide : ne rien faire.

---

## Exemples d'exécution

```
SCAN[◈, focus=anomalies] → outline
```
→ Lire l'input courant, chercher les anomalies, retourner une liste structurée.

---

```
ANALYZE[ctx=technique, ▲] ⟶ COMPRESS[format=STÈLE] → §1
```
→ Analyse technique profonde, puis comprimer en chaîne STÈLE, stocker en §1.

---

```
VALIDATE[*, scope=tests] ? ⊜ : DEBUG[*, focus=error]
```
→ Valider tous les tests. Si OK → archiver. Sinon → déboguer les erreurs.

---

```
CREATE[◈, type=component, from=scratch] ⟶ VALIDATE[◈, scope=types]
```
→ Créer le composant depuis zéro, puis valider les types.

---

```
FIND[input=*, type=usage, pattern=◈] ⟶ ANALYZE[ctx=technique, depth=2]
```
→ Trouver toutes les utilisations du pattern courant, puis analyser en profondeur.

---

```
ADD[target=*, what=error-handling] ⟶ VALIDATE[*, scope=error]
```
→ Ajouter la gestion d'erreurs à tous les éléments, puis valider.

---

```
@stele⌒ @metalangage⌒
SCAN[◈] ? RESONE[◈, layers=all] ⟶ COMPRESS[format=STÈLE] → §1 : ⊜
```
→ Déclarer les skills en lazy load. Scanner l'input. Si résultat : activer
  la résonance complète, comprimer en STÈLE, stocker. Sinon : archiver.

---

## Intégration Pierre de Rosette

```
[Local — zéro token]           [Cloud — Claude]
Prose utilisateur
      ↓
  rosetta.js                   SPC_SKILL.md chargé
  (pattern match               (interprète et exécute
   ou IA locale)                le DSL reçu)
      ↓                               ↑
    DSL SPC  ─────────────────────────┘
```

La Pierre de Rosette génère le DSL.
Ce skill l'exécute.
Aucun token n'est consommé pour la traduction.

---

## Notes de maintenance

- Chaque nouvel opérateur ajouté dans `rosetta.json` doit être documenté ici.
- Les shortcuts de la Pierre de Rosette n'ont pas à être reproduits dans ce skill
  — ils appartiennent à la couche de traduction, pas d'exécution.
- En cas de conflit entre un paramètre explicite et un symbole implicite,
  le paramètre explicite a priorité.
